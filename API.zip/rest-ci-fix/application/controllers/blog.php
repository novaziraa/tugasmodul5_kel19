<?php

defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . '/libraries/REST_Controller.php';
use Restserver\Libraries\REST_Controller;
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, PATCH, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: *');

class Blog extends REST_Controller {

    function __construct($config = 'rest') {
        parent::__construct($config);
        $this->load->database();
    }

    function index_options(){ //Ditambah
        $this->response(['status' => "success"], 202);
    }

    //Menampilkan data blog
    function index_get() {
        $id = $this->get('id');
        if ($id == '') {
            $api = $this->db->get('blog')->result();
        } else {
            $this->db->where('id', $id);
            $api = $this->db->get('blog')->result();
        }
        $this->response($api, 200);
    }

    //Mengirim atau menambah data kontak baru
    function index_post() {
        $data = json_decode($this->input->raw_input_stream, true);
        $insert = $this->db->insert('blog', $data);
        if ($insert) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail'), 502);
        }
    }

    //Memperbarui data kontak yang telah ada
    function index_put($id) {
        $data = json_decode($this->input->raw_input_stream, true);
        $this->db->where('id', $id);
        $update = $this->db->update('blog', $data);
        if ($update) {
            $this->response($data, 200);
        } else {
            $this->response(array('status' => 'fail'), 502);
        }
    }

    //Menghapus salah satu data kontak
    function index_delete($id) {
        $this->db->where('id', $id);
        $delete = $this->db->delete('blog');
        if ($delete) {
            $this->response(array('status' => 'success'), 201);
        } else {
            $this->response(array('status' => 'fail'), 502);
        }
    }
}
?>